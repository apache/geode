/*
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements. See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership. The ASF licenses this file to You under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */
package org.apache.geode.distributed.internal.membership.gms.fd;

import java.util.Objects;
import java.util.concurrent.Callable;


/**
 * Note: this class has a natural ordering that is inconsistent with equals.
 *
 * @param <V>
 */
public class ScheduledTask<V> implements Comparable<ScheduledTask<V>> {
  final long readyAtNanoTime;
  final Callable<V> callable;

  public ScheduledTask(final long readyAtNanoTime, final Callable<V> callable) {
    this.readyAtNanoTime = readyAtNanoTime;
    this.callable = callable;
  }

  @Override
  public boolean equals(final Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final ScheduledTask<?> task = (ScheduledTask<?>) o;
    return readyAtNanoTime == task.readyAtNanoTime &&
        callable.equals(task.callable);
  }

  @Override
  public int hashCode() {
    return Objects.hash(readyAtNanoTime, callable);
  }

  @Override
  public int compareTo(final ScheduledTask<V> o) {
    if (readyAtNanoTime > o.readyAtNanoTime)
      return 1;
    if (readyAtNanoTime < o.readyAtNanoTime)
      return -1;
    return 0;
  }
}
